import json

from aip import AipOcr
from django.http import HttpResponseServerError, HttpResponse

APP_ID = '16691067'
API_KEY = 'S01WYAeNtfRKWUivduqbRv8c'
SECRET_KEY = '04HWnrU6dViGTBhAxVd99v2cObAOmGmK'


def simple(request):
    client = AipOcr(APP_ID, API_KEY, SECRET_KEY)
    image = request.body
    ret = client.webImage(image)
    ret_str = json.dumps(ret, ensure_ascii=False)
    if 'error_code' in ret:
        return HttpResponseServerError(ret_str)  # error_code error_msg
    ret = [i["words"] for i in ret["words_result"]]
    ret_str = json.dumps(ret, ensure_ascii=False)
    return HttpResponse(ret_str)  # ["TSINGTAO","青島睥酒"]
