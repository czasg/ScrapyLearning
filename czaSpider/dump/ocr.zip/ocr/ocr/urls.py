from django.conf.urls import url

from ocr.views import simple

urlpatterns = [
    url('^simple$', simple)
]
